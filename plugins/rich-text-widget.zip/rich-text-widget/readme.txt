﻿=== Rich Text Widget ===
Contributors: julienappert,Ajcrea
Tags: rte,tinymce,widget,rich editor,wysiwyg
Requires at least: 3.0
Tested up to: 3.3.1
Stable tag: trunk

Create rich text widgets (WYSIWYG), with media management.

== Description ==

Caution : the plugin is not compatible with the 0.2 version. So, you should save your content before upgrading. Sorry for the inconvenient.

Create rich text widgets (WYSIWYG), with media management.

== Installation ==

1. Download 'rich-text-widget.zip'
2. unzip and upload 'rich-text-widget' directory to your '/wp-content/plugins' directory
3. Go to the plugin management page and enable the plugin
4. Add the widget "Rich Text" 
5. That's it !

== Screenshots ==

1. Rich Text Widget
2. Adding media

== Changelog ==

= 1.1.1 =
* deactivate user_can_richedit() verification

= 1.1 =
* no more active/deactivate buttons.
* new saving method

= 1.0.4 =
* WP3.3 compatibility

= 1.0.3 =
* improving render

= 1.0.2 =
* debug

= 1.0.1 =
* localization
* description changed