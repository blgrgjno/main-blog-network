<?php
__('Subscribe Me', 'sem-subscribe-me');
__('Widgets that let you display subscribe links to RSS readers such as Google Reader.', 'sem-subscribe-me');
?>