// version 1.0 - original version for WordPress versions less than 3.3
edButtons[edButtons.length] = new edButton('Subscribe2', 'Subscribe2', '[subscribe2]', '', '', -1);