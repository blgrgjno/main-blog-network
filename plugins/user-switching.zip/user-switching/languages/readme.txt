== For Translators ==

If you are looking for the PO files for existing translations, you can download them here:

http://plugins.svn.wordpress.org/user-switching/assets/

If you have created your own translation, or have an update of an existing one, please send it to <john@johnblackbourn.com> so I can bundle it into the next release of the plugin.

Thank you!
John.
